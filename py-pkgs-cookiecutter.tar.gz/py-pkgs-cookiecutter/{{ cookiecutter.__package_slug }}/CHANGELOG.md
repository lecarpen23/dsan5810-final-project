# Changelog

<!--next-version-placeholder-->

## v{{ cookiecutter.package_version }} ({% now 'local', '%d/%m/%Y' %})

- First release of `{{ cookiecutter.__package_slug }}`!