# {{ cookiecutter.__package_slug }}

{{ cookiecutter.package_short_description }}

## Installation

```bash
pip install {{ cookiecutter.__package_slug }}
```

## Usage

- TODO

## Contributing

Clone and set up the repository with

```bash
git clone TODO && cd {{ cookiecutter.__package_slug }}
pip install -e ".[dev]"
```

Install pre-commit hooks with

```bash
pre-commit install
```

Run tests using

```
pytest -v tests
```

