from {{ cookiecutter.__package_slug }} import {{ cookiecutter.__package_slug }}
